USE [Zeris]
GO

/****** Object:  Table [dbo].[RouteRideObservation]    Script Date: 06/09/2016 13:47:41 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[RouteRideObservation](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[SCcode] [nvarchar](50) NOT NULL,
	[No] [nvarchar](max) NULL,
	[DateCallplan] [nvarchar](max) NULL,
	[SC] [nvarchar](max) NULL,
	[CustomerCode] [nvarchar](max) NULL,
	[CustomerName] [nvarchar](max) NULL,
	[Address] [nvarchar](max) NULL,
	[Dist] [nvarchar](max) NULL,
	[Area] [nvarchar](max) NULL,
	[CustomerClassification] [nvarchar](max) NULL,
	[MonthlyCallFrequency] [nvarchar](max) NULL,
	[CustomerType] [nvarchar](max) NULL,
	[FFM] [nvarchar](max) NULL,
	[ObserverName] [nvarchar](max) NULL,
	[TransferTime] [text] NULL,
	[TimeEntering] [nvarchar](max) NULL,
	[MeetCustomer] [nvarchar](max) NULL,
	[MeetPharmacyOwner] [nvarchar](max) NULL,
	[MeetPharmacyOrderingStaff] [nvarchar](max) NULL,
	[MeetPharmacyAssisstant] [nvarchar](max) NULL,
	[TimeToGreet] [nvarchar](max) NULL,
	[TimeToCheckStock] [nvarchar](max) NULL,
	[TimeToTakeOrder] [nvarchar](max) NULL,
	[TimeToNegotiate] [nvarchar](max) NULL,
	[TimeToDoSurvey] [nvarchar](max) NULL,
	[TimeToDiscussOtherServices] [nvarchar](max) NULL,
	[TimeToDoProductDetailing] [nvarchar](max) NULL,
	[TimeToImplementMerchandisingAction] [nvarchar](max) NULL,
	[CheckInventoryToOrder] [nvarchar](max) NULL,
	[ExistingProductDetailing] [nvarchar](max) NULL,
	[NewProductDetailing] [nvarchar](max) NULL,
	[Promotion] [nvarchar](max) NULL,
	[Contract] [nvarchar](max) NULL,
	[MerchandisingPOPM] [nvarchar](max) NULL,
	[HandlingIssues] [nvarchar](max) NULL,
	[OtherServices] [nvarchar](max) NULL,
	[TimeToImplementActionsNegotiatedWithCustomer] [nvarchar](max) NULL,
	[TimeToInputIntoPOES] [nvarchar](max) NULL,
	[SpareTime] [nvarchar](max) NULL,
	[TotalStoreCallTime] [int] NULL,
	[SystemUsedToTakeOrder] [nvarchar](max) NULL,
	[TimingOfOrder] [nvarchar](max) NULL,
	[UpSelling] [nvarchar](max) NULL,
	[CrossSelling] [nvarchar](max) NULL,
	[OrderSuccessful] [nvarchar](max) NULL,
	[DeliveryTimeExpected] [nvarchar](max) NULL,
	[Comments] [nvarchar](max) NULL,
	[WorkDayStartTime] [nvarchar](max) NULL,
	[WorkDayCompletedTime] [nvarchar](max) NULL,
	[TotalWorkDaytime] [text] NULL,
	[LunchTime] [text] NULL,
	[NoonBreak] [text] NULL,
 CONSTRAINT [PK_RouteRideObservation] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

