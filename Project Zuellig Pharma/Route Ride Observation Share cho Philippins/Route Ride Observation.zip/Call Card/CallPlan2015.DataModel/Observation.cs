﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CallPlan2015.DataModel
{
    public class Observation
    {
        public string SC { get; set; }public string CustomerCode { get; set; }
        public string FFM { get; set; }
    }
}
