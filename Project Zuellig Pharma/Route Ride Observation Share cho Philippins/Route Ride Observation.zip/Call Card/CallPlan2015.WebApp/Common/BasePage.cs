﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using CallPlan2015.Common;
using CallPlan2015.DataModel;

namespace CallPlan2015.WebApp.Common
{
	public class BasePage : Page
	{
		public string RedirectUrl(string url)
		{
			return ResolveUrl(url);
		}

       
	}
}